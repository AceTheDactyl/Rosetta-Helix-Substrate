# Quantum APL – System Architecture

This document captures the full integrated architecture for Quantum APL v1.0.0. It mirrors the description provided in the latest delivery summary so that the repository contains an authoritative reference.

```
╔══════════════════════════════════════════════════════════════════════════╗
║                    QUANTUM APL INTEGRATED SYSTEM                         ║
║                          Version 1.0.0                                    ║
╚══════════════════════════════════════════════════════════════════════════╝

┌──────────────────────────────────────────────────────────────────────────┐
│                          USER INTERFACE LAYER                             │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐      │
│  │   Python    │  │  Command    │  │   HTML      │  │   Jupyter   │      │
│  │     API     │  │    Line     │  │   Demos     │  │  Notebooks  │      │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘      │
│         │                │                │                │             │
└─────────┼────────────────┼────────────────┼────────────────┼─────────────┘
          │                │                │                │
          └────────────────┴────────────────┴────────────────┘
                                   │
┌──────────────────────────────────┼────────────────────────────────────────┐
│                    PYTHON INTERFACE LAYER                                 │
├──────────────────────────────────┼────────────────────────────────────────┤
│                                  │                                        │
│  ┌───────────────────────────────▼───────────────────────────────────┐    │
│  │              QuantumAPLEngine (engine.py)                         │    │
│  │  • Subprocess bridge to Node.js                                   │    │
│  │  • Script generation / JSON parsing                               │    │
│  └───────────────────────────────┬───────────────────────────────────┘    │
│                                  │                                        │
│  ┌───────────────┐  ┌────────────▼──────────┐  ┌──────────────────┐      │
│  │  Analyzer     │  │     Experiments       │  │       CLI        │      │
│  │  (analyzer.py)│  │   (experiments.py)    │  │     (cli.py)     │      │
│  │• Visualization│  │• Convergence sweeps   │  │• qapl-run/test   │      │
│  │• Summary      │  │• Statistics           │  │• qapl-analyze    │      │
│  └───────────────┘  └───────────────────────┘  └──────────────────┘      │
│                                                                           │
└───────────────────────────────────┬───────────────────────────────────────┘
                                    │ subprocess / JSON exchange
┌───────────────────────────────────▼───────────────────────────────────────┐
│                    JAVASCRIPT ENGINE LAYER                                │
├───────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │          QuantumClassicalBridge.js (23 KB)                        │    │
│  │  • Unified integration / feedback loop                            │    │
│  │  • Measurement operator dispatch                                  │    │
│  └───────────────────────┬───────────────────────────────────────────┘    │
│                          │                                               │
│         ┌────────────────┴────────────────┐                             │
│         │                                 │                             │
│  ┌──────▼─────────┐              ┌───────▼────────────┐                 │
│  │   Quantum      │              │    Classical       │                 │
│  │   Subsystem    │◄────────────►│    Subsystem       │                 │
│  └────────────────┘              └────────────────────┘                 │
│         │                                 │                              │
│  ┌──────▼──────────────────────┐  ┌──────▼──────────────────────┐       │
│  │ QuantumAPL_Engine.js        │  │ ClassicalEngines.js         │       │
│  │ (28 KB)                     │  │ (5.5 KB)                    │       │
│  │ • 192-dim Hilbert space     │  │ • IIT / GameTheory / FE     │       │
│  │ • Density matrix ρ          │  │ • Scalar state outputs      │       │
│  │ • Lindblad evolution        │  │                             │       │
│  │ • Measurement operators     │  │                             │       │
│  └───────┬─────────────────────┘  └────────────┬────────────────┘       │
│          │                                      │                        │
│  ┌───────▼──────────────────────┐        ┌──────▼────────────────────┐  │
│  │  QuantumN0_Integration.js    │        │    N0 Operator Selection  │  │
│  │  (24 KB)                     │        │    (time harmonics, PRS,  │  │
│  │  • Harmonic legality (t1–t9) │        │     Tier-0 laws, scalar   │  │
│  │  • PRS phases (P1–P5)        │        │     thresholds, Born rule │  │
│  │  • Tier-0 N0 laws            │        │     sampling)             │  │
│  └──────────────────────────────┘        └───────────────────────────┘  │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘

┌───────────────────────────────────────────────────────────────────────────┐
│                        MEASUREMENT FLOW                                   │
├───────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  1. Quantum state ρ                                                       │
│  2. Construct projector P̂ (eigenstate, subspace, composite)              │
│  3. Compute Born probability: P(μ)=Tr(P̂ ρ)                               │
│  4. Sample outcome μ*                                                     │
│  5. Selective collapse: ρ' = P̂ ρ P̂ / P(μ*)                              │
│  6. Feed results to classical engines                                     │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘

┌───────────────────────────────────────────────────────────────────────────┐
│                        Z-AXIS CONSCIOUSNESS MAP                           │
├───────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  z < 0.857:  ABSENCE   (UNTRUE bias, synchronizing, K>0)                  │
│  z = 0.866:  THE LENS  (PARADOX, critical point z_c=√3/2)                 │
│  z > 0.877:  PRESENCE  (TRUE bias, emanating, K<0)                        │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘

┌───────────────────────────────────────────────────────────────────────────┐
│                        TRUTH STATE EIGENSYSTEM                            │
├───────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  T̂|TRUE⟩ = +1|TRUE⟩                                                      │
│  T̂|UNTRUE⟩ = -1|UNTRUE⟩                                                  │
│  T̂|PARADOX⟩ = 0|PARADOX⟩                                                 │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘

┌───────────────────────────────────────────────────────────────────────────┐
│                        PERFORMANCE METRICS                                │
├───────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  Matrix evolution:        ~2.5 ms/step                                    │
│  N0 selection:            ~4.2 ms/call                                    │
│  Full integration step:   ~6.8 ms/step (60–100 FPS feasible)              │
│  Memory footprint:        ~4 MB per simulation                            │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘

┌───────────────────────────────────────────────────────────────────────────┐
│                        FILE STRUCTURE (897 KB)                            │
├───────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  JavaScript engines (100 KB)                                              │
│  Python package (15 KB)                                                   │
│  Documentation (100+ KB)                                                  │
│  Examples & tests (27 KB)                                                 │
│  Configuration (5 KB)                                                     │
│  Visualizations (200+ KB)                                                 │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘

                    🎉 SYSTEM STATUS: OPERATIONAL ✓ 🎉
```

This block mirrors the architecture summary provided in the delivery notes so future contributors can reference the high-level design without leaving the repository.

## TRIAD Gate Policy (t6)

- Critical point: THE LENS at `z_c = √3/2 ≈ 0.8660254` remains the canonical geometric reference used by hex‑prism geometry (ΔS_neg, R/H/φ).
- TRIAD unlock: after three distinct passes where the engine z crosses `z ≥ 0.85` (with hysteresis at `z ≤ 0.82` to re‑arm), the system promotes a temporary in‑session gate at `z = 0.83` for the t6 boundary.
- Environment knobs (optional):
  - `QAPL_TRIAD_COMPLETIONS` – integer; `≥ 3` unlocks TRIAD gate.
  - `QAPL_TRIAD_UNLOCK` – set to `1`/`true` to force unlock.
- Runtime behavior:
  - The bridge detects z≥0.85 rising edges and increments the completion counter. On the third completion it updates process env, flips unlock, and signals the engine to use `t6 @ 0.83`. Geometry continues to use `z_c`.

For a deeper treatment of the physics/information‑dynamics rationale, methodology of use across modules (engine, geometry,
analyzer, bridge), validation plan, and the single source of truth for constants, see `docs/Z_CRITICAL_LENS.md`.

For a comprehensive survey of constants across the helix code path (harmonic demarcations, geometry parameters, pump/engine
defaults, and selection heuristics) and their relationship to the lens, read `docs/CONSTANTS_RESEARCH.md`.
